/**
    @fileOverview CrossBrowser대응, touch대응, 공통기능 대응 컴포넌트
    @author sculove
    @version #__VERSION__#
    @since 2013. 2. 27.
*/
/**
    컴포넌트
**/
jindo.m.Core = jindo.$Class({
	/* @lends jindo.m.Core.prototype */
	$init : function(el,htUserOption) {
		this.option({
			bActivateOnload : true,
			bUseHighlight : true,
			bUseDiagonalTouch : true,
			bUseMomentum : true,
			nDeceleration : 0.0006,
			nWidth : 0,
			nHeight : 0
		});
	},

  /**
      jindo.m.Core 에서 사용하는 모든 인스턴스 변수를 초기화한다.
  **/
	_initVar: function() {
		this._htWElement = {};
    this._bUseH = false;  // 수평 사용여부
    this._bUseV = false;  // 수직 사용여부
    this._nX = 0; // 수평 좌표
    this._nY = 0; // 수직 좌표
    this._bUseDiagonalTouch = this.option("bUseDiagonalTouch");
		// 클릭버그 관련
    this._htClickBug = {
			hasBug : jindo.m.hasClickBug(),
      anchors : null,
      isBlocked : false,
			dummyFnc : function(){return false;},
			hasDummyFnc : false,
			dummyTagForFocus : null
		};
    // offset버그 관련
    this._htOffsetBug = {
      hasBug : jindo.m.hasOffsetBug() && this.option("bUseHighlight"),
      timer : -1,
      elDummyTag : null
    };
    this._htSize = {
      viewWidth : 0,
      viewHeight : 0,
      contWidth : 0,
      contHeight : 0,
      maxX : 0,
      maxY : 0
    };
    this._oTouch = null;
		this._oUIAnimator = null;	// 하위에서 설정
	},
	
  /**
      jindo.m.Core 에서 사용하는 모든 엘리먼트의 참조를 가져온다.
      @param {Varient} el 엘리먼트를 가리키는 문자열이나, HTML엘리먼트
  **/
	_setWrapperElement: function(el) {
		var nHeight = this.option("nHeight"),
			nWidth = this.option("nWidth");
    this._htWElement["view"] = jindo.$Element(el);
		//View 영역 크기 지정
		nHeight = /%$/.test(nHeight) ? nHeight :  (nHeight== 0 ? this._htWElement["view"].css("height") : parseInt(nHeight,10) + "px");
		nWidth = /%$/.test(nWidth) ? nWidth :  (nWidth== 0 ? this._htWElement["view"].css("width") : parseInt(nWidth,10) + "px");
    
    this._htWElement["view"].css({
			"overflow" : "hidden",
			"zIndex" : 2000,
			"height" : nHeight,
			"width" : nWidth,
			"position" : "relative"
		});

		// base is for PreviewFlicking 
		this._htWElement["base"] = this._htWElement["view"].query("." + this.option("sClassPrefix") + "base");
		if(this._htWElement["base"]) {
			this._htWElement["container"] = this._htWElement["base"].query("." + this.option("sClassPrefix") + "container");
			this._htWElement["base"].css({
				"position" :"relavite"
			});
		} else {
			this._htWElement["container"] = this._htWElement["view"].query("." + this.option("sClassPrefix") + "container") || this._htWElement["view"].first();	
		}
		this._htWElement["container"].css({
			// "position" : "absolute",
      // "left" : "0px",
      // "top" : "0px",
      "zIndex" : 1
		});
    this._createOffsetBugDummyTag();
	},

	_onActivate : function() {
		if(!this._oTouch) {
			this._oTouch = new jindo.m.Touch(this._htWElement["view"].$value(), {
				nMoveThreshold : 0,
				nMomentumDuration : (jindo.m.getDeviceInfo().android ? 500 : 200),
				nTapThreshold : 1,
				nSlopeThreshold : 5,
				nEndEventThreshold : (jindo.m.getDeviceInfo().win8 ? 100 : 0)
			});
		}
		this._attachEvent();
	},

  /**
      jindo.m.Core 에서 사용하는 모든 이벤트를 할당한다.
  **/
	_attachEvent : function() {
	  this._htEvent = {};
	  /* Touch 이벤트용 */
	  this._htEvent["touchStart"] = jindo.$Fn(this._onStart, this).bind();
	  this._htEvent["touchMove"] = jindo.$Fn(this._onMove, this).bind();
	  this._htEvent["touchEnd"] = jindo.$Fn(this._onEnd, this).bind();
	  // this._htEvent["document"] = jindo.$Fn(this._onDocumentStart, this).attach(document, "touchstart");
	  this._oTouch.attach({
      touchStart : this._htEvent["touchStart"],
      touchMove : this._htEvent["touchMove"],
      touchEnd :  this._htEvent["touchEnd"]
	  });
	  // if(this.option("bAutoResize")) {
	  //     this._htEvent["rotate"] = jindo.$Fn(this._onRotate, this).bind();
	  //     jindo.m.bindRotate(this._htEvent["rotate"]);
	  // }
	},

  /**
      jindo.m.Core 에서 사용하는 모든 이벤트를 해제한다.
  **/
	_detachEvent : function() {
		// this._htEvent["document"].detach(document,"touchstart");
		this._oTouch.detachAll();
		// if (this._elDummyTag) {
		// 	this._htWElement["scroller"].remove(this._elDummyTag);
		// }
	},

  /**
      Boundary를 초과하지 않는 X (left) 포지션 반환
      @param {Number} nPos
  **/
  _getX : function(nPos) {
    return ( nPos >= 0 ? 0 : (nPos <= this._htSize.maxX ? this._htSize.maxX : nPos) );
  },

  /**
      Boundary를 초과하지 않는 Y (top) 포지션 반환
      @param {Number} nPos
  **/
  _getY : function(nPos) {
    return ( nPos >= 0 ? 0 : (nPos <= this._htSize.maxY ? this._htSize.maxY : nPos) );
  },

  /**
   * UIAnimator관련 이벤트를 할당한다.
   */
  _attachAniEvent : function() {
    if(this._oUIAnimator) {
      this._htEvent["startAni"] = jindo.$Fn(this._onStartAniImpl, this).bind();
      this._htEvent["panelStartAni"] = jindo.$Fn(this._onPanelStartAniImpl, this).bind();
      this._htEvent["panelEndAni"] = jindo.$Fn(this._onPanelEndAniImpl, this).bind();
      this._htEvent["moveAni"] = jindo.$Fn(this._onMoveAniImpl, this).bind();
      this._htEvent["endAni"] = jindo.$Fn(this._onEndAniImpl, this).bind();
      this._oUIAnimator.attach({
        "start" : this._htEvent["startAni"],
        "move" : this._htEvent["moveAni"],
        "panelStart" : this._htEvent["panelStartAni"],
        "panelEnd" : this._htEvent["panelEndAni"],
        "end" : this._htEvent["endAni"]
      });
    }
  },

  /**
   * UIAnimator관련 이벤트를 해제한다.
   */
  _detachAniEvent : function() {
    if(this._oUIAnimator) {
      this._oUIAnimator.detachAll();
    }
  },

  // UIAnimator 구현 이벤트 (하위 클래스에서 구현)
  // UIAnimator의 start 이벤트 핸들러
  _onStartAniImpl : function(we) {},
  // UIAnimator의 panelStart 이벤트 핸들러
  _onPanelStartAniImpl : function(we) {},
  // UIAnimator의 move 이벤트 핸들러
  _onMoveAniImpl : function(we) {
    this._nX = we.endX;
    this._nY = we.endY;
  },
  // UIAnimator의 panelEnd 이벤트 핸들러
  _onPanelEndAniImpl : function(we) {},
  // UIAnimator의 end 이벤트 핸들러
  _onEndAniImpl : function(we) {},

  /**
      deactivate 실행시 호출됨
  **/
	_onDeactivate : function() {
		this._detachEvent();
		this._oTouch.deactivate();
	},

	set : function(oAni) {
		this._oUIAnimator = oAni;
		this._oUIAnimator.set(this._htWElement);
    this._attachAniEvent();
		return this._oUIAnimator;
	},

  /**
   * UIAnimator를 반환한다.
   * @return {jindo.m.UIAnimator} UIAnimator를 반환
   *
   * @method getUIAnimator
   */
  getUIAnimator : function() {
    return this._oUIAnimator;
  },

  /**
   * 영역의 사이즈를 refresh한다.
   *
   * @method refresh
   */
  refresh : function() {
    var welView = this._htWElement["view"],
      welContainer = this._htWElement["container"],
      nWidthLeft = parseInt(welView.css("borderLeftWidth"),10),
      nWidthRight = parseInt(welView.css("borderRightWidth"),10),
      nHeightTop = parseInt(welView.css("borderTopWidth"),10),
      nHeightBottom = parseInt(welView.css("borderBottomWidth"),10);
    nWidthLeft = isNaN(nWidthLeft) ? 0 : nWidthLeft;
    nWidthRight = isNaN(nWidthRight) ? 0 : nWidthRight;
    nHeightTop = isNaN(nHeightTop) ? 0 : nHeightTop;
    nHeightBottom = isNaN(nHeightBottom) ? 0 : nHeightBottom;

    // 사이즈 갱신
    this._htSize.viewWidth = welView.width() - nWidthLeft - nWidthRight;
    this._htSize.viewHeight = welView.height() - nHeightTop - nHeightBottom;
    this._htSize.contWidth = welContainer.width();
    this._htSize.contHeight = welContainer.height();
    
    // A링크를 탐색
    this._refreshAnchor();
  },

  _refreshAnchor : function() {
    if(this._htClickBug.hasBug) {
      this._htClickBug.anchors = jindo.$$("A", this._htWElement["view"].$value());
      if(!this._htClickBug.anchors) {
        this._htClickBug.hasBug = false;
      }
    }
  },

  /**
      모멘텀을 계산하여 앞으로 이동할 거리와 시간을 속성으로 갖는 객체를 반환함
      @param {Number} nDistance
      @param {Number} nSpeed
      @param {Number} nMomentum
      @param {Number} nMaxDistUpper
      @param {Number} nMaxDistLower
      @param {Number} nSize
  **/
  _calcMomentum: function (nDistance, nSpeed, nMomentum, nMaxDistUpper, nMaxDistLower, nSize) {
      var nDeceleration = this.option("nDeceleration"),
          nNewDist = nMomentum / nDeceleration,
          nNewTime = 0,
          nOutsideDist = 0;
      // console.debug("momentum",{
      //   distance:nDistance,
      //   speed : nSpeed,
      //   momentum : nMomentum,
      //   upper : nMaxDistUpper,
      //   lower : nMaxDistLower,
      //   newDist : nNewDist
      // });
      if (nDistance > 0 && nNewDist > nMaxDistUpper) {
        nOutsideDist = nSize / (6 / (nNewDist / nSpeed * nDeceleration));
        nMaxDistUpper = nMaxDistUpper + nOutsideDist;
        nSpeed = nSpeed * nMaxDistUpper / nNewDist;
        nNewDist = nMaxDistUpper;
      } else if (nDistance < 0 && nNewDist > nMaxDistLower) {
        nOutsideDist = nSize / (6 / (nNewDist / nSpeed * nDeceleration));
        nMaxDistLower = nMaxDistLower + nOutsideDist;
        nSpeed = nSpeed * nMaxDistLower / nNewDist;
        nNewDist = nMaxDistLower;
      }
      nNewDist = nNewDist * (nDistance < 0 ? -1 : 1);
      nNewTime = nSpeed / nDeceleration;
      // console.debug({
      //     nDist: nNewDist,
      //     nTime: Math.round(nNewTime)
      // });
      return {
          nDist: nNewDist,
          nTime: Math.round(nNewTime)
      };
  },  

  /**
      Anchor를 삭제
  **/
  _clearAnchor : function() {
    // console.log("clear : " + this._htClickBug.hasBug + " | " + this._htClickBug.isBlocked);
    if(this._htClickBug.hasBug && !this._htClickBug.isBlocked) {
      var aClickAddEvent = null,
        anchor = null;
      for(var i=0, nLen=this._htClickBug.anchors.length; i<nLen; i++) {
        anchor = this._htClickBug.anchors[i];
        if(!anchor.___isClear___) {
          if(this._htClickBug.dummyFnc !== anchor.onclick) {
            anchor._onclick = anchor.onclick;
          }
          anchor.onclick = this._htClickBug.dummyFnc;
          anchor.___isClear___ = true;
          aClickAddEvent = anchor.___listeners___ || [];
          jindo.$A(aClickAddEvent).forEach(function(v,i,a) {
            ___Old__removeEventListener___.call(anchor, "click", v.listener, v.useCapture);
          });
        }
      }
      this._htClickBug.isBlocked = true;
    }
  },

  /**
      Anchor를 복원
  **/
  _restoreAnchor : function() {
    // console.log("restore : " + this._htClickBug.hasBug + " | " + this._htClickBug.isBlocked);
    if(this._htClickBug.hasBug && this._htClickBug.isBlocked) {
      var aClickAddEvent = null,
        anchor = null;
      for(var i=0, nLen=this._htClickBug.anchors.length; i<nLen; i++) {
        anchor = this._htClickBug.anchors[i];
        if(anchor.___isClear___) {
          if(this._htClickBug.dummyFnc !== anchor._onclick) {
            anchor.onclick = anchor._onclick;
          } else {
            anchor.onclick = null;
          }
          anchor.___isClear___ = null;
          aClickAddEvent = this._aAnchor[i].___listeners___ || [];
          jindo.$A(aClickAddEvent).forEach(function(v,i,a) {
            ___Old__addEventListener___.call(anchor, "click", v.listener, v.useCapture);
          });
        }
      }
      this._bBlocked = false;
    }
  }, 	

 	/**
      Touchstart시점 이벤트 핸들러
      @param {jindo.$Event} we
  **/
  _onStart : function(we) {
      // console.log("touchstart (" + we.nX + "," + we.nY + ")");
      if(this.hasOffsetBug()){
        this._htOffsetBug.elDummyTag.focus();
        this._clearOffsetBug();
      }
      /**
          touchStart 내부 스크롤로직이 실행되기 전

          @event beforeTouchStart
          @param {String} sType 커스텀 이벤트명
          @param {Number} nLeft Scroller의 left 값
          @param {Number} nTop Scroller의 top 값
          @param {Number} nMaxScrollLeft Scroller의 최대 left 값
          @param {Number} nMaxScrollTop Scroller의 최대 top 값
          @param {jindo.$Event} oEvent touchStart 이벤트 객체
          @param {Function} stop 수행시 touchStart 이벤트가 발생하지 않음
      **/
      // if(this._fireTouchEvent("beforeTouchStart",we)) {
          this._clearAnchor();
          this._oUIAnimator.clearDuration();
          this._startImpl(we);
          // this._isAnimating = false;
          // this._isControling = true;
          // this._isStop = false;
          // 이동중 멈추었을 경우
          // this._stopScroll();
          /**
              touchStart 내부 스크롤로직이 실행된 후

              @event touchStart
              @param {String} sType 커스텀 이벤트명
              @param {Number} nLeft Scroller의 left 값
              @param {Number} nTop Scroller의 top 값
              @param {Number} nMaxScrollLeft Scroller의 최대 left 값
              @param {Number} nMaxScrollTop Scroller의 최대 top 값
              @param {jindo.$Event} oEvent touchStart 이벤트 객체
              @param {Function} stop 수행시 영향을 받는것이 없음
          **/
          // if(!this._fireTouchEvent("touchStart",we)) {
          //     we.stop();
          // }
      // } else {
      //     we.stop();
      // }
  },

  /**
      이동시점 이벤트 핸들러
      @param {jindo.$Event} we
  **/
  _onMove : function(we) {
    // this._clearTouchEnd();
    // console.log("touchmove (" + we.nX + "," + we.nY + "), Vector (" + we.nVectorX + "," + we.nVectorY + ") sMoveType : " + we.sMoveType, we);
    // if(this._isUse("pull")) {
    //     this._inst("pull").touchMoveForUpdate(we, this.nMaxScrollTop);
    // }
    
    /** 시스템 스크롤 막기 */
    var weParent = we.oEvent;
    if(we.sMoveType === jindo.m.MOVETYPE[0]) {  // 수평이동시
      if(this._bUseH) {
        // 수평스크롤인 경우 시스템 스크롤 막고, 컴포넌트 기능 수행
        weParent.stop(jindo.$Event.CANCEL_ALL);
      } else {
        return;
      }
    } else if(we.sMoveType === jindo.m.MOVETYPE[1]) {   //수직이동시
      if(this._bUseV) {
        // 수직스크롤인 경우 시스템 스크롤 막고, 컴포넌트 기능 수행
        weParent.stop(jindo.$Event.CANCEL_ALL);
      } else {
        return;
      }
    } else if(we.sMoveType === jindo.m.MOVETYPE[2]) {   //대각선일 경우
      if(this._bUseDiagonalTouch) {
        // 대각선인 경우 시스템 스크롤 막고, 컴포넌트 기능 수행
        weParent.stop(jindo.$Event.CANCEL_ALL);
      } else{
        return;
      }
    } else if(we.sMoveType === jindo.m.MOVETYPE[6] || we.sMoveType === jindo.m.MOVETYPE[7] || we.sMoveType === jindo.m.MOVETYPE[8]) {  
      weParent.stop(jindo.$Event.CANCEL_ALL);
    } else {    // 탭, 롱탭인 경우, 다 막기
      weParent.stop(jindo.$Event.CANCEL_ALL);
      return true;
    }

    /**
        touchMove 내부 스크롤로직이 실행되기 전

        @event beforeTouchMove
        @param {String} sType 커스텀 이벤트명
        @param {Number} nLeft Scroller의 left 값
        @param {Number} nTop Scroller의 top 값
        @param {Number} nMaxScrollLeft Scroller의 최대 left 값
        @param {Number} nMaxScrollTop Scroller의 최대 top 값
        @param {jindo.$Event} oEvent touchMove  이벤트 객체
        @param {Function} stop 수행시 move 이벤트가 발생하지 않음
    **/
  // if (this._fireTouchEvent("beforeTouchMove",we)) {
      // var nNewLeft, nNewTop;
      this._clearOffsetBug();
      this._moveImpl(we);
      /**
          touchMove 내부 스크롤로직이 실행된 후

          @event touchMove
          @param {String} sType 커스텀 이벤트명
          @param {Number} nLeft Scroller의 left 값
          @param {Number} nTop Scroller의 top 값
          @param {Number} nMaxScrollLeft Scroller의 최대 left 값
          @param {Number} nMaxScrollTop Scroller의 최대 top 값
          @param {jindo.$Event} oEvent touchMove  이벤트 객체
          @param {Function} stop 수행시 영향을 받는것이 없음
      **/
     
      // if(!this._fireTouchEvent("touchMove",we)) {
      //     we.stop();
      // }

  // } else {
  //     we.stop();
  // }
  },

  /**
      Touchend 시점 이벤트 핸들러
      @param {jindo.$Event} we
  **/
  _onEnd : function(we) {
      // console.log("touchend [" + we.sMoveType + "](" + we.nX + "," + we.nY + "), Vector(" + we.nVectorX + "," + we.nVectorY + "), MomentumY : "+ we.nMomentumY + ", speedY : " + we.nSpeedY);
      /**
          touchEnd 내부 스크롤로직이 실행되기 전

          @event beforeTouchEnd
          @param {String} sType 커스텀 이벤트명
          @param {Number} nLeft Scroller의 left 값
          @param {Number} nTop Scroller의 top 값
          @param {Number} nMaxScrollLeft Scroller의 최대 left 값
          @param {Number} nMaxScrollTop Scroller의 최대 top 값
          @param {jindo.$Event} oEvent touchEnd 이벤트 객체
          @param {Function} stop 수행시 touchEnd 이벤트가 발생하지 않음
      **/

	// if(this._isUse("pull")){
	// 	this._inst("pull").pullUploading();
	// }

    // if (this._fireTouchEvent("beforeTouchEnd",we)) {
        this._clearOffsetBug();
        // this._clearTouchEnd();
        // addConsole("end : " + we.sMoveType);
        // 1) 스크롤이 아닌 경우
        if (we.sMoveType === jindo.m.MOVETYPE[3] || we.sMoveType === jindo.m.MOVETYPE[4] || we.sMoveType === jindo.m.MOVETYPE[5]) {
            // this._isControling = false;
            // if (!this._isStop) {
                // if(this.bUseHighlight) {
                    this._restoreAnchor();
                // }
            // }
        } else {   // 2) 스크롤인 경우
            // 클릭 이후 페이지 뒤로 돌아왔을 경우, 문제가됨. 동작중인 상태를 초기화함
            this._endImpl(we);
            // this._endForScroll(we);
            // if(this.isClickBug || this.nVersion < 4.1) {
            //     we.oEvent.stop(jindo.$Event.CANCEL_DEFAULT);
            // }
        }
        /**
            touchEnd 내부 스크롤로직이 실행된 직후

            @event touchEnd
            @param {String} sType 커스텀 이벤트명
            @param {Number} nLeft Scroller의 left 값
            @param {Number} nTop Scroller의 top 값
            @param {Number} nMaxScrollLeft Scroller의 최대 left 값
            @param {Number} nMaxScrollTop Scroller의 최대 top 값
            @param {jindo.$Event} oEvent touchEnd 이벤트 객체
            @param {Function} 수행시 영향 받는것 없음.
        **/
    //     if(!this._fireTouchEvent("touchEnd",we)) {
    //         we.stop();
    //     }
    // } else {
    //     we.stop();
    // }
  },

  _getMomentumData : function(we, nThreshold, isBounce) {
    var htMomentumX = { nDist:0, nTime:0 },
      htMomentumY = { nDist:0, nTime:0 },
      htData = {
        momentumX : we.nMomentumX,
        momentumY : we.nMomentumY,
        distanceX : we.nDistanceX,
        distanceY : we.nDistanceY,
        x : this._nX,
        y : this._nY,
        nextX : this._nX,
        nextY : this._nY
      };
    // 모멘텀인 경우
    if(this.option("bUseMomentum") && 
      ( (we.nMomentumX && we.nMomentumX > nThreshold) || 
        (we.nMomentumY && we.nMomentumY > nThreshold) ) ) {
      if(this._bUseH) {
        htMomentumX = this._calcMomentum(we.nDistanceX, we.nSpeedX, we.nMomentumX, -this._nX, -this._htSize.maxX + this._nX, isBounce ? this._htSize.viewWidth : 0);
      }
      if(this._bUseV) {
        htMomentumY = this._calcMomentum(we.nDistanceY, we.nSpeedY, we.nMomentumY, -this._nY, -this._htSize.maxY + this._nY, isBounce ? this._htSize.viewHeight : 0);
      }
      htData.nextX = this._nX + htMomentumX.nDist;
      htData.nextY = this._nY + htMomentumY.nDist;
      htData.duration = Math.max(Math.max(htMomentumX.nTime, htMomentumY.nTime),10);
    } else {
      htData.duration = 0;
    }
    return htData;
  },


  /**
      translate의 포지션을 스타일로 바꾼다.
      @deprecated 
      @method makeStylePos
      @param {jindo.$Element} wel
  **/
  _makeStylePos : function(wel) {
      var ele = wel.$value(),
        oUI = this.getUIAnimator(),
        htTranslateOffset = jindo.m.getCssOffset(ele),
        htStyleOffset = oUI.getStyleOffset(wel),
        htCss = {
          top : (htTranslateOffset.top + htStyleOffset.top) + "px",
          left : (htTranslateOffset.left + htStyleOffset.left) + "px"
        };
      htCss[oUI.prefix("Transform")] = "";
      htCss[oUI.prefix("TransitionDuration")] = "";
      wel.css(htCss);
      this._htOffsetBug.elDummyTag.focus();
      // alert("complete");
  },  

  _createOffsetBugDummyTag : function() {
    if(this.hasOffsetBug()) {
      this._htOffsetBug.elDummyTag = jindo.$$.getSingle("._offsetbug_dummy_atag_", this._htWElement["view"]);
      if(!this._htOffsetBug.elDummyTag) {
          this._htOffsetBug.elDummyTag = jindo.$("<a href='javascript:void(0);' style='position:absolute;height:0px;width:0px;' class='_offsetbug_dummy_atag_'></a>");
          this._htWElement["view"].append(this._htOffsetBug.elDummyTag);
      } 
    }
  },

  _clearOffsetBug : function() {
    if(this.hasOffsetBug()) {
        clearTimeout(this._htOffsetBug.timer);
        this._htOffsetBug.timer = -1;
    }
  },

  _fixOffsetBugImpl : function() {
    if(this.hasOffsetBug()) {
      var self = this;
      var welTarget = this.getUIAnimator().getTarget(true);
      this._clearOffsetBug();
      this._htOffsetBug.timer = setTimeout(function() {
        if(welTarget) {
          self._makeStylePos(welTarget);
        }
      }, 200);
    }
  },

  hasOffsetBug : function() {
    return this._htOffsetBug.hasBug;
  },

  /**
      jindo.m.Core 에서 사용하는 모든 객체를 release 시킨다.
      @method destroy
  **/
	destroy: function() {
	// 	this.deactivate();
	// 	for(var p in this._htWElement) {
	// 		this._htWElement[p] = null;
	// 	}
	// 	this._htWElement = null;
	// 	this._oTouch.destroy();
	// 	delete this._oTouch;
	}
}).extend(jindo.m.UIComponent);